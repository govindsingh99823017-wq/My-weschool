import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDxT9iPzvi72gHL77_TetuJqId_b8hHJQQ",
  authDomain: "fastwork-16024.firebaseapp.com",
  databaseURL: "https://fastwork-16024-default-rtdb.firebaseio.com",
  projectId: "fastwork-16024",
  storageBucket: "fastwork-16024.firebasestorage.app",
  messagingSenderId: "977594324176",
  appId: "1:977594324176:web:b62f901b6dc2c7d3d9bad5",
  measurementId: "G-3JT8HN99PV"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Analytics conditionally (it might not work in some environments)
export const analytics = typeof window !== "undefined" ? isSupported().then(yes => yes ? getAnalytics(app) : null) : null;

export const db = getFirestore(app);
export const auth = getAuth(app);

export default app;
