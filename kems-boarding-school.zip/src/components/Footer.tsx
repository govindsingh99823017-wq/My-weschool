import { Facebook, Instagram, Twitter, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-background text-foreground py-16 border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded flex items-center justify-center text-background font-serif font-bold text-xl">
                K
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-xl tracking-wider">KEMS BOARDING</span>
              </div>
            </div>
            <p className="text-secondary leading-relaxed text-sm">
              Empowering students with knowledge, character, and skills to lead in a global society. Join the KEMS family today.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded bg-card border border-border flex items-center justify-center hover:text-primary transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded bg-card border border-border flex items-center justify-center hover:text-primary transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded bg-card border border-border flex items-center justify-center hover:text-primary transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded bg-card border border-border flex items-center justify-center hover:text-primary transition-colors">
                <Youtube size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-[11px] uppercase tracking-widest text-primary font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm text-secondary">
              <li><a href="#home" className="hover:text-primary transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-primary transition-colors">About Us</a></li>
              <li><a href="#academics" className="hover:text-primary transition-colors">Academics</a></li>
              <li><a href="#facilities" className="hover:text-primary transition-colors">Facilities</a></li>
              <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[11px] uppercase tracking-widest text-primary font-bold mb-6">Admissions</h4>
            <ul className="space-y-4 text-sm text-secondary">
              <li><a href="#" className="hover:text-primary transition-colors">Admission Process</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Fee Structure</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Scholarships</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Online Inquiry</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Download Brochure</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[11px] uppercase tracking-widest text-primary font-bold mb-6">Contact Info</h4>
            <ul className="space-y-4 text-sm text-secondary">
              <li className="flex items-start gap-3">
                <span className="text-primary">Addr:</span>
                <span>Hindaun City, Rajasthan, India</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary">Phone:</span>
                <span>+91 7597466803</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary">Email:</span>
                <span>info@kemsboarding.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-secondary">
          <p>© 2026 KEMS Boarding School. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
