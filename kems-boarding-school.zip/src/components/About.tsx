import { motion } from "motion/react";

export default function About() {
  return (
    <section id="about" className="py-24 bg-background border-t border-border relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4 pt-12">
                <img
                  src="https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=500"
                  alt="Students"
                  className="rounded-lg border border-border shadow-lg aspect-[3/4] object-cover grayscale hover:grayscale-0 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                <img
                  src="https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=500"
                  alt="Classroom"
                  className="rounded-lg border border-border shadow-lg aspect-square object-cover grayscale hover:grayscale-0 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-4">
                <img
                  src="https://images.unsplash.com/photo-1511629091441-ee46146481b6?auto=format&fit=crop&q=80&w=500"
                  alt="Library"
                  className="rounded-lg border border-border shadow-lg aspect-square object-cover grayscale hover:grayscale-0 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                <img
                  src="https://images.unsplash.com/photo-1577891772247-36d586be5e66?auto=format&fit=crop&q=80&w=500"
                  alt="Sports"
                  className="rounded-lg border border-border shadow-lg aspect-[3/4] object-cover grayscale hover:grayscale-0 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            {/* Decorative Badge */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-primary rounded flex items-center justify-center text-background text-center p-4 shadow-xl border-4 border-background">
              <div className="font-serif font-bold text-sm leading-tight">
                ESTD<br /><span className="text-2xl">2010</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-6">
              A Tradition of <span className="text-primary italic">Excellence</span> and Innovation.
            </h2>
            <div className="space-y-6 text-lg text-secondary leading-relaxed">
              <p>
                KEMS Boarding School was founded with a vision to provide quality education that goes beyond textbooks. We believe in nurturing the unique potential of every child through a balanced approach to academics, sports, and character development.
              </p>
              <p>
                Our campus in Hindaun City is designed to be a "home away from home" for our residential students, providing a safe, supportive, and stimulating environment where they can grow and excel.
              </p>
              <div className="grid grid-cols-2 gap-8 pt-6">
                <div>
                  <div className="text-primary font-serif text-xl mb-1">Our Mission</div>
                  <p className="text-sm text-secondary">To empower students with the skills and values needed to succeed in the 21st century.</p>
                </div>
                <div>
                  <div className="text-primary font-serif text-xl mb-1">Our Vision</div>
                  <p className="text-sm text-secondary">To be a leading educational institution known for academic rigor and holistic growth.</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
